import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Lecture et compréhension des données
#################################################################
carDetails = pd.read_csv('data.csv')
carDetails.head()
################################################################
carDetails.shape
################################################################
carDetails.describe()
################################################################
carDetails.info()
####################### Visualisation de notre données #######################
#Le graphe de paires repose sur deux figures de base, l'histogramme et le nuage
#de points. L'histogramme sur la diagonale nous permet de voir la distribution 
#d'une seule variable, tandis que les diagrammes de dispersion 
#des triangles supérieur et inférieur indiquent la relation (ou l'absence de relation) 
#entre deux variables.
  
##########################################################################
# visualisation des données
#la matrice de correlation ################
plt.figure(figsize = (20,15))  
sns.heatmap(carDetails.corr(),annot = True)
plt.show()
# heatmap  c est une  carte thermique fonctionne par corrélation. Cela vous 
#montre quelles variables sont corrélées lesunes aux autres d'une échelle de 1
# comme étant la plus corrélée et -1 non corrélé. 
##############################################################################
######################## preparation de données ###########################
# À partir des diagrammes de dispersion ci-dessus et de la carte thermique, 
#nous constatons une forte corrélation entre: 
#1. longueur, poids à vide,empattement et largeur de voiture; nous pouvons 
#donc en supprimer 3 sur 4,
#nous allons donc laisser tomber la largeur de voiture, le poids à vide et
#l'empattement 
#2.il est une forte corrélation de 0,97 entre highwaympg et citympg, alors
#laissez tomber highwaympg

carDetails.drop(['carwidth','curbweight','wheelbase','highwaympg'], axis =1,
                inplace = True)
#we can also remove carID  as its just a serial number 
carDetails.drop(['car_ID'], axis =1, inplace = True)
carDetails.info()
carDetails.shape

#variable categorique  
#subplot de prix
plt.figure(figsize=(20,8))

plt.subplot(1,2,1)
plt.title('Car Price Distribution Plot')
sns.distplot(carDetails.price)

plt.subplot(1,2,2)
plt.title('Car Price Spread')
sns.boxplot(y=carDetails.price)

plt.show()
####subplot de type de motor 
plt.figure(figsize=(20,8))

plt.subplot(1,2,1)
plt.title('Engine Type Histogram')
sns.countplot(carDetails.enginetype, palette=("Blues_d"))

plt.subplot(1,2,2)
plt.title('Engine Type vs Price')
sns.boxplot(x=carDetails.enginetype, y=carDetails.price, palette=("PuBuGn"))

plt.show()

df = pd.DataFrame(carDetails.groupby(['enginetype'])['price'].mean().sort_values(ascending = False))
df.plot.bar(figsize=(8,6))
plt.title('Engine Type vs Average Price')
plt.show()
##########################################################################
#################### la despersion des prix #######################
# la despersion des prix :on remarquant que presque  80% des enregistrement
#inferieure a 20000 ----> alors pour l entreprise de la chine il a faut pense
#de produire des voiture ace interval pour avoir un bon effectef des client  

#

c = [i for i in range(1,206,1)]
fig = plt.figure()
plt.scatter(c,carDetails['price'])
fig.suptitle('price vs index', fontsize=20)              # Plot heading 
plt.xlabel('index', fontsize=18)                          # X-label
plt.ylabel('price', fontsize=16)  

#Il y a une variable nommée CarName qui est composée de deux parties - le premier mot est
#le nom de "compagnie automobile" et le second est le "modèle de voiture". Par exemple, chevrolet
#impala a 'chevrolet' comme nom de compagnie et 'impala' comme nom de modèle
# .Nous devons considérer uniquement le nom de la société en tant que variable indépendante pour la construction du modèle.
###### reglage Colonne companyname ##########
carDetails["CarName"] = carDetails["CarName"].str.replace('-', ' ')
carDetails.CarName.unique()

carDetails["CarName"] = carDetails.CarName.map(lambda x: x.split(" ", 1)[0])
# Comme nous avons des données redondantes dans carName, corrigeons-le

carDetails.CarName = carDetails['CarName'].str.lower()
carDetails['CarName'] = carDetails['CarName'].str.replace('vw','volkswagen')
carDetails['CarName'] = carDetails['CarName'].str.replace('vokswagen','volkswagen')
carDetails['CarName'] = carDetails['CarName'].str.replace('toyouta','toyota')
carDetails['CarName'] = carDetails['CarName'].str.replace('porcshce','porsche')
carDetails['CarName'] = carDetails['CarName'].str.replace('maxda','mazda')
carDetails['CarName'] = carDetails['CarName'].str.replace('maxda','mazda')

#### converter oui  a 1 et non  a 0   Les Variables binaire ###
carDetails['fueltype'] = carDetails['fueltype'].map({'gas': 1, 'diesel': 0})
carDetails['aspiration'] = carDetails['aspiration'].map({'std': 1, 'turbo': 0})
carDetails['doornumber'] = carDetails['doornumber'].map({'two': 1, 'four': 0})
carDetails['enginelocation'] = carDetails['enginelocation'].map({'front': 1, 'rear': 0})
#Creation  des dummy variables 

df = pd.get_dummies(carDetails)
df.head()
#######################################
#Comme nous pouvons le voir, nous avons peu de champs catégoriels tels que carName, 
#carbody, driveWheel, le système de carburant, le nombre de cylindres, 
#le type de moteur. Ainsi, générons d'abord des colonnes factices pour toutes ces 
#colonnes.



#Redimensionner les entités en utilisant la normalisation¶

cols_to_norm = ['symboling', 'carlength', 'carheight', 
         'enginesize', 'boreratio', 'stroke', 'compressionratio','horsepower',
         'peakrpm', 'citympg', 'price']
# Normaliser uniquement les champs numériques
#Le but d’avoir un tel intervalle restreint est de réduire l’espace de variation
 #des valeurs d’une feature et par
#conséquent réduire l’effet des outliers.
normalised_df = df[cols_to_norm].apply(lambda x: (x-np.mean(x))/ (max(x) - min(x)))
normalised_df.head()

df['symboling'] = normalised_df['symboling']
df['carlength'] = normalised_df['carlength']
df['carheight'] = normalised_df['carheight']
df['enginesize'] = normalised_df['enginesize']
df['boreratio'] = normalised_df['boreratio']
df['stroke'] = normalised_df['stroke']
df['price'] = normalised_df['price']
df['compressionratio'] = normalised_df['compressionratio']
df['horsepower'] = normalised_df['horsepower']
df['peakrpm']= normalised_df['peakrpm']
df['citympg'] = normalised_df['citympg']
df.head()


#partisionner les doonées en 2 parties ( test , Apprentissage)
#voir tout les  colonnes
refinedcol = df.columns
refinedcol
X = df[['symboling', 'fueltype', 'aspiration', 'doornumber', 'enginelocation',
       'carlength', 'carheight', 'enginesize', 'boreratio', 'stroke',
       'compressionratio', 'horsepower', 'peakrpm', 'citympg',
       'CarName_alfa', 'CarName_audi', 'CarName_bmw', 'CarName_buick',
       'CarName_chevrolet', 'CarName_dodge', 'CarName_honda', 'CarName_isuzu',
       'CarName_jaguar', 'CarName_mazda', 'CarName_mercury',
       'CarName_mitsubishi', 'CarName_nissan', 'CarName_peugeot',
       'CarName_plymouth', 'CarName_porsche', 'CarName_renault',
       'CarName_saab', 'CarName_subaru', 'CarName_toyota',
       'CarName_volkswagen', 'CarName_volvo', 'carbody_convertible',
       'carbody_hardtop', 'carbody_hatchback', 'carbody_sedan',
       'carbody_wagon', 'drivewheel_4wd', 'drivewheel_fwd', 'drivewheel_rwd',
       'enginetype_dohc', 'enginetype_dohcv', 'enginetype_l', 'enginetype_ohc',
       'enginetype_ohcf', 'enginetype_ohcv', 'enginetype_rotor',
       'cylindernumber_eight', 'cylindernumber_five', 'cylindernumber_four',
       'cylindernumber_six', 'cylindernumber_three', 'cylindernumber_twelve',
       'cylindernumber_two', 'fuelsystem_1bbl', 'fuelsystem_2bbl',
       'fuelsystem_4bbl', 'fuelsystem_idi', 'fuelsystem_mfi',
       'fuelsystem_mpfi', 'fuelsystem_spdi', 'fuelsystem_spfi']]

# # # Putting response variable to y
y = df['price']
#######################################################
#random_state est la graine utilisée par le générateur de nombres aléatoires,
#il peut s'agir de n'importe quel entier.
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.7 ,test_size = 0.3, random_state=100)


#help(rfe)
# l'objectif de l'élimination récursive des entités (RFE) est de sélectionner 
#des entités en considérant de manière récursive des ensembles d'entités de
#plus en plus petits.

# Importing RFE and LinearRegression
# Importing RFE and LinearRegression
from sklearn.feature_selection import RFE
from sklearn.linear_model import LinearRegression
# Exécution de RFE avec le numéro de sortie de la variable égal à 15
lm = LinearRegression()
rfe = RFE(lm, 15)             # running RFE
rfe = rfe.fit(X_train, y_train)
print(rfe.support_)           # Printing the boolean results
print(rfe.ranking_)
#voir les variable choiser par RFE
X_train.columns[rfe.support_]

# les variable qu on doit supprimer 
X_train.columns
col = X_train.columns[~rfe.support_]

############
print("Avant  Suppression des colonnes  choiser par RFE")
X_train.columns
X_train1 = X_train.drop(col,1)
print("Apres Suppression des colones ")
X_train1.columns
df.head()
#Ajouter un variable constante 
#############################################################################
import statsmodels.api as sm  
X_train1 = sm.add_constant(X_train1)

lm_1 = sm.OLS(y_train,X_train1).fit() # Running the linear model

print(lm_1.summary())

#############################################################################

X_train2 = X_train1.drop('enginetype_dohcv', 1)


lm_2 = sm.OLS(y_train,X_train2).fit()
 # Running the linear model

print(lm_2.summary())

#############################################################################

X_train3 = X_train2.drop('cylindernumber_eight', 1)


lm_3 = sm.OLS(y_train,X_train3).fit()
 # Running the linear model

print(lm_3.summary())

# on verifier les valeur de VIF en utilise les variable qu ont une valeur => 5
# VIF POUR LA Multicolinearité
#Le facteur d'inflation de variance (VIF) est utilisé pour détecter la présence
#de multicolinéarité. Les facteurs d'inflation de la variance (VIF) mesurent
#l'ampleur de l'inflation de la variance des coefficients de régression estimé
#s par rapport au fait que les variables de prédiction ne sont pas liées de
#manière linéaire.

#On l'obtient en faisant régresser chaque variable indépendante, disons X sur
# les variables indépendantes restantes (disons Y et Z), et en vérifiant quelle part (de X) est expliquée par ces variables.
from statsmodels.stats.outliers_influence import variance_inflation_factor

def checkVIF(X):
    vif = pd.DataFrame()
    vif['Features'] = X.columns
    vif['VIF'] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
    vif['VIF'] = round(vif['VIF'], 2)
    vif = vif.sort_values(by = "VIF", ascending = False)
    return(vif)

checkVIF(X_train3)


####################
# calculer valeur de VIF 
# df.head()

######################
# Suppression de variables hautement corrélées et de variables non significatives
X_train4 = X_train3.drop('enginetype_rotor', 1)
# Creating deuxieme  model avec fonction fit
lm_4 = sm.OLS(y_train,X_train4).fit()
#Voyons le résumé de notre deuxième modèle linéaire
print(lm_4.summary())

#Comme nous pouvons voir le cylindernumber_eight son vif est 3.43 et 
#aussi nouspouvons voir qu'il est corrélé positivement avec enginetype_dohcv
#(0.44) et engineize (0.49) permet d'aller de l'avant et de le laisser tomber

checkVIF(X_train4)

####################################################
X_train5 = X_train4.drop('enginesize', 1)
# Creating deuxieme  model avec fonction fit
lm_5 = sm.OLS(y_train,X_train5).fit()
#Voyons le résumé de notre deuxième modèle linéaire
print(lm_5.summary())

######################################################
X_train6 = X_train5.drop('CarName_audi', 1)
# Creating deuxieme  model avec fonction fit
lm_6 = sm.OLS(y_train,X_train6).fit()
#Voyons le résumé de notre deuxième modèle linéaire
print(lm_6.summary())

#####################################################

X_train7 = X_train6.drop('cylindernumber_three', 1)
# Creating deuxieme  model avec fonction fit
lm_7 = sm.OLS(y_train,X_train7).fit()
#Voyons le résumé de notre deuxième modèle linéaire
print(lm_7.summary())

#####################################################

X_train8 = X_train7.drop('cylindernumber_two', 1)
# Creating deuxieme  model avec fonction fit
lm_8 = sm.OLS(y_train,X_train8).fit()
#Voyons le résumé de notre deuxième modèle linéaire
print(lm_8.summary())
######################################################

#####################################################
checkVIF(X_train8)
#####################################################################"
# Ajout de variable constante pour tester le cadre de données
# Adding  constant variable to test dataframe
X_test_m8 = sm.add_constant(X_test)
# Creating X_test_m12 dataframe by dropping variables from X_test_m12
X_test_m8 = X_test_m8.drop([ 'symboling', 'fueltype', 'aspiration', 'doornumber', 'enginelocation',
        'carheight', 'enginesize',  
       'compressionratio', 'horsepower', 'peakrpm', 'citympg', 'CarName_alfa',
       'CarName_audi',   'CarName_chevrolet',
       'CarName_dodge', 'CarName_honda', 'CarName_isuzu', 'CarName_jaguar',
       'CarName_mazda', 'CarName_mercury', 'CarName_mitsubishi',
       'CarName_nissan', 'CarName_peugeot', 'CarName_plymouth',
        'CarName_renault', 'CarName_saab', 'CarName_subaru',
       'CarName_toyota', 'CarName_volkswagen', 'CarName_volvo',
       'carbody_convertible', 'carbody_hardtop', 'carbody_hatchback',
       'carbody_sedan', 'carbody_wagon', 'drivewheel_4wd', 'drivewheel_fwd',
       'drivewheel_rwd', 'enginetype_dohc', 'enginetype_dohcv', 'enginetype_l',
       'enginetype_ohc', 'enginetype_ohcf', 'enginetype_ohcv',
       'enginetype_rotor', 'cylindernumber_eight', 'cylindernumber_five',
       'cylindernumber_six', 'cylindernumber_three',
        'cylindernumber_two', 'fuelsystem_1bbl',
       'fuelsystem_2bbl', 'fuelsystem_4bbl', 'fuelsystem_idi',
       'fuelsystem_mfi', 'fuelsystem_mpfi', 'fuelsystem_spdi',
       'fuelsystem_spfi'], axis=1)
X_test_m8.info()
# Making predictions
y_pred_m8 = lm_8.predict(X_test_m8)
y_pred_m8


# Actual vs Predicted
c = [i for i in range(1,63,1)]
fig = plt.figure()
plt.plot(c,y_test, color="blue", linewidth=3.5, linestyle="-")     #Plotting Actual
plt.plot(c,y_pred_m8, color="red",  linewidth=3.5, linestyle="-")  #Plotting predicted
fig.suptitle('Actual and Predicted', fontsize=20)              # Plot heading 
plt.xlabel('Index', fontsize=18)                               # X-label
plt.ylabel('Car Price', fontsize=16)  
###########################################"
#Évaluation du modèle:

#Permet de disperser l'erreur et de voir si l'erreur est un bruit
#aléatoire ou blanc, ou si elle a un motif
fig = plt.figure()
plt.scatter(y_test,y_pred_m8)
fig.suptitle('y_test vs y_pred', fontsize=20)              # Plot heading 
plt.xlabel('y_test', fontsize=18)                          # X-label
plt.ylabel('y_pred', fontsize=16) 
X_test_m8 = X_test_m8.drop('stroke', 1)
#######################################

lm_t = sm.OLS(y_test,X_test_m8).fit()
print(lm_t.summary())
